# app.py (refatorado e simplificado)
import os
import logging
from flask import Flask, jsonify, g
import pyodbc
from services import pcp_service

# ---------------- Logging ----------------
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger(__name__)

app = Flask(__name__)

# ---------------- Config DB (env vars) ----------------
DB_DRIVER = os.getenv("DB_DRIVER", "ODBC Driver 17 for SQL Server")
DB_SERVER = os.getenv("DB_SERVER", "10.0.255.102")
DB_NAME   = os.getenv("DB_NAME", "PROTHEUS11")
DB_USER   = os.getenv("DB_USER", "sa")
DB_PASS   = os.getenv("DB_PASS", "Flamb@2014")
FILIAL    = os.getenv("FILIAL", "01").zfill(2)

CNXN_STR = (
    f"DRIVER={{{DB_DRIVER}}};"
    f"SERVER={DB_SERVER};"
    f"DATABASE={DB_NAME};"
    f"UID={DB_USER};"
    f"PWD={DB_PASS};"
    "TrustServerCertificate=yes;"
)

def get_db_connection():
    if 'db' not in g:
        try:
            g.db = pyodbc.connect(CNXN_STR)
        except Exception:
            logger.exception("Erro ao conectar ao banco de dados")
            g.db = None
            raise
    return g.db

@app.teardown_appcontext
def close_db_connection(exception):
    db = g.pop('db', None)
    if db is not None:
        try:
            db.close()
        except Exception:
            logger.warning("Falha ao fechar conexão de banco", exc_info=True)

def get_pcp_service():
    cnxn = get_db_connection()
    return pcp_service.PCPService(cnxn, FILIAL)

# Decorador para padronizar endpoints
def pcp_endpoint(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*args, **kwargs):
        pcp = get_pcp_service()
        try:
            result = fn(pcp, *args, **kwargs)
            if result is None:
                return jsonify({"error": "Erro ao buscar dados."}), 500
            return jsonify(result)
        except Exception:
            logger.exception("Erro em endpoint")
            return jsonify({"error": "Erro interno no servidor"}), 500
    return wrapper

@app.route("/")
def home():
    return "Bem-vindo ao Dashboard de PCP Protheus!"

# ---------------- Rotas ----------------
@app.route('/api/estoque', methods=['GET'])
@pcp_endpoint
def get_estoque_route(pcp):
    return pcp.get_estoque()

@app.route('/api/pedidos', methods=['GET'])
@pcp_endpoint
def get_pedidos_carteira_route(pcp):
    return pcp.get_pedidos_carteira()

@app.route('/api/ops', methods=['GET'])
@pcp_endpoint
def get_ops_em_aberto_route(pcp):
    return pcp.get_ops_em_aberto()

@app.route('/api/mrp-necessidade', methods=['GET'])
@pcp_endpoint
def get_necessidade_materia_prima_route(pcp):
    return pcp.get_necessidade_materia_prima()

@app.route('/api/ops-detalhado', methods=['GET'])
@pcp_endpoint
def get_ops_detalhado_route(pcp):
    return pcp.get_ops_detalhado()

@app.route('/api/estoque-negativo-justificativa', methods=['GET'])
@pcp_endpoint
def get_estoque_negativo_justificativa_route(pcp):
    return pcp.get_estoque_negativo_justificativa()

@app.route('/api/empenho-pendente-op-encerrada', methods=['GET'])
@pcp_endpoint
def get_empenho_pendente_op_encerrada_route(pcp):
    return pcp.get_empenho_pendente_op_encerrada()

@app.route('/api/ops-encerradas-diferenca', methods=['GET'])
@pcp_endpoint
def get_ops_parcialmente_encerradas_route(pcp):
    return pcp.get_ops_parcialmente_encerradas()

if __name__ == '__main__':
    app.run(debug=True)
